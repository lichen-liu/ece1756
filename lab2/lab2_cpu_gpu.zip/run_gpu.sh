for var in "$@"
do
	./conv_gpu hinton.pgm "$var"
done
